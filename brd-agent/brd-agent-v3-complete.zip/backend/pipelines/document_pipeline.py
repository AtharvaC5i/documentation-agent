"""
Document Generation Pipeline — Professional formatting.

Key improvements:
- Strict section word limits enforced via prompts (target 45-60 pages)
- Professional styles: correct fonts, colours, spacing, table styles
- Proper TOC with heading styles so Word can auto-generate it
- Cover page with project metadata table
- Header/footer with project name and page numbers
- Section page breaks
- Alternating row table shading
- Stores final .docx to outputs/ folder
"""

import os
import re
from datetime import datetime
from typing import List, Dict, Any

from models.project import Project, ProjectStore
from utils.file_utils import get_output_path
from utils.logger import info, success, warn, divider

try:
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor, Cm, Emu
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    import lxml.etree as etree
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

# ── Colour palette ──────────────────────────────────────────────────────────
NAVY       = RGBColor(0x1F, 0x3A, 0x5F)   # H1
BLUE       = RGBColor(0x25, 0x63, 0xEB)   # H2
DARK_GREY  = RGBColor(0x37, 0x41, 0x51)   # H3
BODY       = RGBColor(0x11, 0x18, 0x27)   # body text
MUTED      = RGBColor(0x64, 0x74, 0x8B)   # captions / notes
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
TABLE_HDR  = RGBColor(0x1F, 0x3A, 0x5F)
ROW_ALT    = "EFF6FF"
ROW_WHITE  = "FFFFFF"


def _set_cell_bg(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    # Remove existing shd
    for shd in tcPr.findall(qn("w:shd")):
        tcPr.remove(shd)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def _add_paragraph_border_left(para, hex_color: str = "2563EB", width: int = 18):
    """Add a left border to a paragraph (used for H2 accent)."""
    pPr = para._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), str(width))
    left.set(qn("w:space"), "6")
    left.set(qn("w:color"), hex_color)
    pBdr.append(left)
    pPr.append(pBdr)


def _set_para_spacing(para, before: int = 0, after: int = 6, line: float = 1.15):
    pPr = para._p.get_or_add_pPr()
    pSpr = OxmlElement("w:spacing")
    pSpr.set(qn("w:before"), str(before * 20))
    pSpr.set(qn("w:after"), str(after * 20))
    pSpr.set(qn("w:line"), str(int(line * 240)))
    pSpr.set(qn("w:lineRule"), "auto")
    pPr.append(pSpr)


def _add_page_number_footer(doc: Document, project_name: str):
    """Add footer with project name left and page number right."""
    for section in doc.sections:
        footer = section.footer
        footer.is_linked_to_previous = False
        para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        para.clear()
        para.alignment = WD_ALIGN_PARAGRAPH.RIGHT

        # Project name (left side via tab)
        run_left = para.add_run(f"{project_name}  |  ")
        run_left.font.size = Pt(8)
        run_left.font.color.rgb = MUTED
        run_left.font.name = "Calibri"

        # Page number field
        run_pg = para.add_run()
        run_pg.font.size = Pt(8)
        run_pg.font.color.rgb = MUTED
        fldChar1 = OxmlElement("w:fldChar")
        fldChar1.set(qn("w:fldCharType"), "begin")
        instrText = OxmlElement("w:instrText")
        instrText.set(qn("xml:space"), "preserve")
        instrText.text = " PAGE "
        fldChar2 = OxmlElement("w:fldChar")
        fldChar2.set(qn("w:fldCharType"), "separate")
        fldChar3 = OxmlElement("w:fldChar")
        fldChar3.set(qn("w:fldCharType"), "end")
        run_pg._r.append(fldChar1)
        run_pg._r.append(instrText)
        run_pg._r.append(fldChar2)
        run_pg._r.append(fldChar3)


def _add_header(doc: Document, project_name: str, client_name: str):
    """Add running header with project and client name."""
    for section in doc.sections:
        header = section.header
        header.is_linked_to_previous = False
        para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        para.clear()
        para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = para.add_run(f"BRD — {project_name}  |  {client_name}  |  CONFIDENTIAL")
        run.font.size = Pt(8)
        run.font.color.rgb = MUTED
        run.font.name = "Calibri"
        run.font.italic = True
        # Bottom border on header paragraph
        pPr = para._p.get_or_add_pPr()
        pBdr = OxmlElement("w:pBdr")
        bottom = OxmlElement("w:bottom")
        bottom.set(qn("w:val"), "single")
        bottom.set(qn("w:sz"), "4")
        bottom.set(qn("w:space"), "1")
        bottom.set(qn("w:color"), "E2E8F0")
        pBdr.append(bottom)
        pPr.append(pBdr)


class DocumentPipeline:

    def __init__(self, project: Project, store: ProjectStore):
        self.project = project
        self.store = store

    async def run(self):
        self.project.status = "generating_document"
        self.project.progress_message = "Generating Word document..."
        self.store.save(self.project)
        divider(f"DOCUMENT PIPELINE — {self.project.project_name}")

        if not DOCX_AVAILABLE:
            self.project.status = "error"
            self.project.progress_message = "python-docx not installed. Run: pip install python-docx"
            self.store.save(self.project)
            return

        output_path = get_output_path(self.project.project_name)
        doc = Document()

        info("DOC", "Setting up styles...")
        self._setup_styles(doc)

        info("DOC", "Adding header and footer...")
        _add_header(doc, self.project.project_name, self.project.client_name)
        _add_page_number_footer(doc, self.project.project_name)

        info("DOC", "Building cover page...")
        self._add_cover_page(doc)

        info("DOC", "Adding version history...")
        self._add_version_history(doc)

        info("DOC", "Inserting table of contents...")
        self._add_toc(doc)

        # Sections
        approved = [s for s in self.project.generated_sections if s.get("approved", False)]
        if not approved:
            approved = self.project.generated_sections

        info("DOC", f"Rendering {len(approved)} sections...")
        for i, section in enumerate(approved):
            self._render_section(doc, section)
            info("DOC", f"  [{i+1}/{len(approved)}] {section.get('name','')}")

        doc.save(output_path)

        self.project.document_path = output_path
        self.project.status = "complete"
        self.project.progress_message = "Document ready for download."
        self.store.save(self.project)
        success("DOC", f"Document saved → {output_path}")

    def _setup_styles(self, doc: Document):
        """Configure all document styles."""
        # Page margins — professional document standard
        for sec in doc.sections:
            sec.top_margin = Cm(2.54)
            sec.bottom_margin = Cm(2.54)
            sec.left_margin = Cm(3.17)
            sec.right_margin = Cm(2.54)

        # Normal / body text
        normal = doc.styles["Normal"]
        normal.font.name = "Calibri"
        normal.font.size = Pt(11)
        normal.font.color.rgb = BODY
        nPr = normal._element.get_or_add_pPr()
        spr = OxmlElement("w:spacing")
        spr.set(qn("w:after"), "120")   # 6pt after
        spr.set(qn("w:line"), "276")    # 1.15 line spacing
        spr.set(qn("w:lineRule"), "auto")
        nPr.append(spr)

        # Heading 1 — section title, navy, page break before
        h1 = doc.styles["Heading 1"]
        h1.font.name = "Calibri"
        h1.font.size = Pt(18)
        h1.font.bold = True
        h1.font.color.rgb = NAVY
        h1pPr = h1._element.get_or_add_pPr()
        h1spr = OxmlElement("w:spacing")
        h1spr.set(qn("w:before"), "480")
        h1spr.set(qn("w:after"), "200")
        h1pPr.append(h1spr)

        # Heading 2 — subsection, blue with left accent border
        h2 = doc.styles["Heading 2"]
        h2.font.name = "Calibri"
        h2.font.size = Pt(14)
        h2.font.bold = True
        h2.font.color.rgb = BLUE
        h2pPr = h2._element.get_or_add_pPr()
        h2spr = OxmlElement("w:spacing")
        h2spr.set(qn("w:before"), "280")
        h2spr.set(qn("w:after"), "120")
        h2pPr.append(h2spr)

        # Heading 3 — sub-subsection, dark grey
        h3 = doc.styles["Heading 3"]
        h3.font.name = "Calibri"
        h3.font.size = Pt(12)
        h3.font.bold = True
        h3.font.color.rgb = DARK_GREY
        h3pPr = h3._element.get_or_add_pPr()
        h3spr = OxmlElement("w:spacing")
        h3spr.set(qn("w:before"), "200")
        h3spr.set(qn("w:after"), "80")
        h3pPr.append(h3spr)

    def _add_cover_page(self, doc: Document):
        """Professional cover page."""
        # Spacer
        for _ in range(4):
            p = doc.add_paragraph()
            _set_para_spacing(p, 0, 0)

        # Document type badge
        badge = doc.add_paragraph()
        badge.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = badge.add_run("BUSINESS REQUIREMENTS DOCUMENT")
        r.font.name = "Calibri"
        r.font.size = Pt(11)
        r.font.bold = True
        r.font.color.rgb = BLUE
        r.font.letter_spacing = Pt(2)
        _set_para_spacing(badge, 0, 8)

        # Project name — large
        title = doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        tr = title.add_run(self.project.project_name)
        tr.font.name = "Calibri"
        tr.font.size = Pt(32)
        tr.font.bold = True
        tr.font.color.rgb = NAVY
        _set_para_spacing(title, 0, 12)

        # Horizontal rule
        rule = doc.add_paragraph()
        rule.alignment = WD_ALIGN_PARAGRAPH.CENTER
        rule.add_run("─" * 50).font.color.rgb = MUTED
        _set_para_spacing(rule, 4, 16)

        # Metadata table
        table = doc.add_table(rows=5, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER

        meta_rows = [
            ("Prepared for",   self.project.client_name),
            ("Industry",       self.project.industry),
            ("Prepared by",    ", ".join(self.project.team_members) or "Project Team"),
            ("Date",           datetime.now().strftime("%B %d, %Y")),
            ("Document Version", f"v{self.project.version}.0  —  DRAFT"),
        ]

        for i, (label, value) in enumerate(meta_rows):
            row = table.rows[i]
            # Label cell
            lc = row.cells[0]
            lc.text = label
            lc.paragraphs[0].runs[0].font.bold = True
            lc.paragraphs[0].runs[0].font.size = Pt(10)
            lc.paragraphs[0].runs[0].font.color.rgb = MUTED
            lc.paragraphs[0].runs[0].font.name = "Calibri"
            _set_cell_bg(lc, "F8FAFC")
            # Value cell
            vc = row.cells[1]
            vc.text = value
            vc.paragraphs[0].runs[0].font.size = Pt(10)
            vc.paragraphs[0].runs[0].font.name = "Calibri"
            vc.paragraphs[0].runs[0].font.color.rgb = BODY

        # Set column widths
        for row in table.rows:
            row.cells[0].width = Cm(5)
            row.cells[1].width = Cm(9)

        doc.add_page_break()

    def _add_version_history(self, doc: Document):
        """Version history table."""
        h = doc.add_heading("Document Version History", level=1)
        _add_paragraph_border_left(h, "2563EB", 24)

        table = doc.add_table(rows=2, cols=4)
        table.style = "Table Grid"

        # Header row
        headers = ["Version", "Date", "Author", "Description"]
        for i, h_text in enumerate(headers):
            cell = table.rows[0].cells[i]
            cell.text = h_text
            r = cell.paragraphs[0].runs[0]
            r.font.bold = True
            r.font.size = Pt(9)
            r.font.color.rgb = WHITE
            r.font.name = "Calibri"
            _set_cell_bg(cell, "1F3A5F")

        # Data row
        data_row = table.rows[1]
        vals = [
            f"v{self.project.version}.0",
            datetime.now().strftime("%Y-%m-%d"),
            (self.project.team_members[0] if self.project.team_members else "Project Team"),
            "Initial draft generated by BRD Agent",
        ]
        for i, val in enumerate(vals):
            cell = data_row.cells[i]
            cell.text = val
            r = cell.paragraphs[0].runs[0]
            r.font.size = Pt(9)
            r.font.name = "Calibri"

        doc.add_paragraph()
        doc.add_page_break()

    def _add_toc(self, doc: Document):
        """Insert Word TOC field — updates when opened in Word."""
        h = doc.add_heading("Table of Contents", level=1)

        p = doc.add_paragraph()
        run = p.add_run()
        # TOC field code
        fldChar_begin = OxmlElement("w:fldChar")
        fldChar_begin.set(qn("w:fldCharType"), "begin")
        instrText = OxmlElement("w:instrText")
        instrText.set(qn("xml:space"), "preserve")
        instrText.text = 'TOC \\o "1-3" \\h \\z \\u'
        fldChar_sep = OxmlElement("w:fldChar")
        fldChar_sep.set(qn("w:fldCharType"), "separate")
        placeholder = OxmlElement("w:t")
        placeholder.text = "[ Right-click this text → Update Field to generate Table of Contents ]"
        fldChar_end = OxmlElement("w:fldChar")
        fldChar_end.set(qn("w:fldCharType"), "end")
        r_el = run._r
        r_el.append(fldChar_begin)
        r_el.append(instrText)
        r_el.append(fldChar_sep)
        r_el.append(placeholder)
        r_el.append(fldChar_end)
        run.font.color.rgb = MUTED
        run.font.size = Pt(10)
        run.font.italic = True

        doc.add_page_break()

    def _render_section(self, doc: Document, section: Dict[str, Any]):
        """Render a generated BRD section into the document."""
        content = section.get("content", "")
        if not content:
            return

        lines = content.split("\n")
        i = 0
        main_heading_added = False
        in_table = False
        table_lines = []

        while i < len(lines):
            line = lines[i]
            stripped = line.strip()

            # Empty line — skip but flush pending table
            if not stripped:
                if in_table and table_lines:
                    self._render_markdown_table(doc, table_lines)
                    table_lines = []
                    in_table = False
                i += 1
                continue

            # Table detection — collect all table rows
            if stripped.startswith("|"):
                table_lines.append(stripped)
                in_table = True
                i += 1
                continue
            elif in_table:
                self._render_markdown_table(doc, table_lines)
                table_lines = []
                in_table = False

            # H1 / H2 / H3 headings
            if stripped.startswith("#### "):
                p = doc.add_heading(stripped[5:], level=3)
            elif stripped.startswith("### "):
                p = doc.add_heading(stripped[4:], level=3)
            elif stripped.startswith("## "):
                text = stripped[3:]
                p = doc.add_heading(text, level=2)
                _add_paragraph_border_left(p, "2563EB", 18)
            elif stripped.startswith("# "):
                text = stripped[2:]
                if not main_heading_added:
                    p = doc.add_heading(text, level=1)
                    main_heading_added = True
                else:
                    p = doc.add_heading(text, level=2)
                    _add_paragraph_border_left(p, "2563EB", 18)

            # Bullet list
            elif stripped.startswith("- ") or stripped.startswith("* "):
                text = stripped[2:]
                p = doc.add_paragraph(style="List Bullet")
                self._add_inline_formatted_run(p, text)
                p.runs[0].font.name = "Calibri" if p.runs else None

            # Numbered list
            elif len(stripped) > 2 and stripped[0].isdigit() and stripped[1] in ".)" :
                text = stripped[3:] if len(stripped) > 3 else stripped[2:]
                p = doc.add_paragraph(style="List Number")
                self._add_inline_formatted_run(p, text)

            # Regular paragraph
            else:
                if not main_heading_added:
                    p = doc.add_heading(section.get("name", "Section"), level=1)
                    main_heading_added = True
                p = doc.add_paragraph()
                self._add_inline_formatted_run(p, stripped)
                _set_para_spacing(p, 0, 6, 1.15)

            i += 1

        # Flush any remaining table
        if in_table and table_lines:
            self._render_markdown_table(doc, table_lines)

        # Quality note — small, muted
        q = section.get("quality_pct", "")
        n = section.get("req_count", 0)
        if q:
            note = doc.add_paragraph(f"Quality: {q} · Requirements used: {n}")
            _set_para_spacing(note, 0, 0)
            if note.runs:
                note.runs[0].font.size = Pt(7.5)
                note.runs[0].font.color.rgb = MUTED
                note.runs[0].font.italic = True

        doc.add_page_break()

    def _render_markdown_table(self, doc: Document, table_lines: List[str]):
        """Convert markdown table to a styled Word table."""
        rows = []
        for line in table_lines:
            # Skip separator lines |---|---|
            if all(c in "-|: " for c in line):
                continue
            cells = [c.strip() for c in line.split("|") if c.strip()]
            if cells:
                rows.append(cells)

        if not rows:
            return

        num_cols = max(len(r) for r in rows)
        table = doc.add_table(rows=len(rows), cols=num_cols)
        table.style = "Table Grid"

        for row_idx, row_data in enumerate(rows):
            is_header = row_idx == 0
            fill = "1F3A5F" if is_header else (ROW_ALT if row_idx % 2 == 1 else ROW_WHITE)

            for col_idx, cell_text in enumerate(row_data):
                if col_idx >= num_cols:
                    break
                cell = table.rows[row_idx].cells[col_idx]
                cell.text = ""
                p = cell.paragraphs[0]
                run = p.add_run(cell_text)
                run.font.name = "Calibri"
                run.font.size = Pt(9)
                run.font.bold = is_header
                run.font.color.rgb = WHITE if is_header else BODY
                _set_cell_bg(cell, fill)

        doc.add_paragraph()

    def _add_inline_formatted_run(self, para, text: str):
        """Parse **bold** and *italic* inline markdown."""
        parts = re.split(r"(\*\*.*?\*\*|\*.*?\*)", text)
        for part in parts:
            if part.startswith("**") and part.endswith("**") and len(part) > 4:
                run = para.add_run(part[2:-2])
                run.bold = True
                run.font.name = "Calibri"
            elif part.startswith("*") and part.endswith("*") and len(part) > 2:
                run = para.add_run(part[1:-1])
                run.italic = True
                run.font.name = "Calibri"
            elif part:
                run = para.add_run(part)
                run.font.name = "Calibri"
