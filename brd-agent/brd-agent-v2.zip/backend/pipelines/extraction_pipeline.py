"""
Extraction Pipeline
Normalizes transcripts, parses user stories, builds Requirements Pool and Glossary.
All LLM calls go to Databricks served models.
"""

import json
import traceback
from typing import List, Dict

from models.project import Project, ProjectStore, Requirement
from utils.databricks_client import call_databricks_llm, parse_llm_json
from utils.logger import info, success, warn, error, step, divider, llm_call, llm_response
from agents.section_suggester import suggest_sections_from_coverage
from agents.conflict_detector import detect_conflicts_and_gaps


class ExtractionPipeline:

    def __init__(self, project: Project, store: ProjectStore):
        self.project = project
        self.store = store

    def _update_progress(self, pct: int, message: str):
        self.project.progress = pct
        self.project.progress_message = message
        self.store.save(self.project)

    async def run(self):
        divider(f"EXTRACTION PIPELINE — {self.project.project_name}")
        try:
            # ── Step 1: Normalize transcript ──────────────────────────────
            self._update_progress(5, "Normalizing transcript...")
            normalized_transcript = ""
            if self.project.transcript_raw:
                info("NORMALIZE", f"Raw transcript: {len(self.project.transcript_raw)} chars")
                normalized_transcript = await self._normalize_transcript(self.project.transcript_raw)
                success("NORMALIZE", f"Normalized transcript: {len(normalized_transcript)} chars")
            else:
                warn("NORMALIZE", "No transcript provided — skipping")

            # ── Step 2: Extract from transcript ───────────────────────────
            self._update_progress(20, "Extracting requirements from transcript...")
            transcript_requirements = []
            if normalized_transcript:
                transcript_requirements = await self._extract_from_transcript(normalized_transcript)
                success("EXTRACT", f"{len(transcript_requirements)} requirements extracted from transcript")
            else:
                warn("EXTRACT", "No normalized transcript — skipping transcript extraction")

            # ── Step 3: Parse user stories ────────────────────────────────
            self._update_progress(40, "Parsing user stories...")
            story_requirements = []
            if self.project.user_stories_raw:
                info("STORIES", f"Raw user stories: {len(self.project.user_stories_raw)} chars")
                story_requirements = await self._parse_user_stories(self.project.user_stories_raw)
                success("STORIES", f"{len(story_requirements)} requirements parsed from user stories")
            else:
                warn("STORIES", "No user stories provided — skipping")

            # ── Step 4: Build glossary ────────────────────────────────────
            self._update_progress(55, "Building glossary...")
            all_text = (self.project.transcript_raw or "") + "\n" + (self.project.user_stories_raw or "")
            glossary = await self._build_glossary(all_text)
            success("GLOSSARY", f"{len(glossary)} terms defined")

            # ── Step 5: Merge requirements pool ───────────────────────────
            self._update_progress(65, "Merging requirements pool...")
            all_requirements = transcript_requirements + story_requirements
            seen = set()
            unique_requirements = []
            for r in all_requirements:
                if r.req_id not in seen:
                    seen.add(r.req_id)
                    unique_requirements.append(r)

            dupes = len(all_requirements) - len(unique_requirements)
            info("POOL", f"Total: {len(all_requirements)} | Duplicates removed: {dupes} | Final pool: {len(unique_requirements)}")

            type_counts = {}
            for r in unique_requirements:
                type_counts[r.type] = type_counts.get(r.type, 0) + 1
            for t, c in sorted(type_counts.items()):
                info("POOL", f"  {t:<25} {c}")

            self.project.requirements_pool = unique_requirements
            self.project.glossary = glossary

            # ── Step 6: Conflict & gap detection ─────────────────────────
            self._update_progress(75, "Detecting conflicts and gaps...")
            info("CONFLICTS", "Running conflict and gap analysis...")
            conflicts, gaps, coverage = await detect_conflicts_and_gaps(
                self.project.requirements_pool,
                self.project.project_name,
                self.project.description
            )
            self.project.conflicts = conflicts
            self.project.gaps = gaps
            self.project.section_coverage = coverage

            if conflicts:
                warn("CONFLICTS", f"{len(conflicts)} conflict(s) detected — human resolution required")
                for c in conflicts:
                    warn("CONFLICTS", f"  [{c.get('impact','?').upper()}] {c.get('description','')}")
            else:
                success("CONFLICTS", "No conflicts detected")

            strong = sum(1 for v in coverage.values() if v == "strong")
            weak   = sum(1 for v in coverage.values() if v == "weak")
            none_  = sum(1 for v in coverage.values() if v == "none")
            info("COVERAGE", f"Sections — strong: {strong} | weak: {weak} | none: {none_}")
            if gaps:
                warn("COVERAGE", f"{len(gaps)} gap(s) flagged for client follow-up")

            # ── Step 7: Section suggestion ────────────────────────────────
            self._update_progress(90, "Suggesting BRD sections...")
            info("SECTIONS", "Running AI section suggestion...")
            suggested = await suggest_sections_from_coverage(
                coverage, self.project.description, self.project.industry
            )
            self.project.suggested_sections = suggested
            suggested_count = sum(1 for s in suggested if s.get("suggested"))
            success("SECTIONS", f"{suggested_count}/{len(suggested)} sections pre-selected by AI")

            self.project.status = "extracted"
            self._update_progress(100, "Extraction complete.")
            divider("EXTRACTION COMPLETE")

        except Exception as e:
            full_error = traceback.format_exc()
            error("PIPELINE", f"Fatal error: {str(e)}")
            print("\n" + "=" * 60)
            print("FULL TRACEBACK:")
            print(full_error)
            print("=" * 60 + "\n")
            self.project.status = "error"
            self.project.progress_message = f"Extraction failed: {str(e)}"
            self.store.save(self.project)
            raise Exception(full_error)

    async def _normalize_transcript(self, raw_transcript: str) -> str:
        system_prompt = """You are a transcript normalization specialist.
Your job is to clean and normalize meeting transcripts while preserving all information.

Rules:
1. Remove filler words (um, uh, you know, like, basically, so basically)
2. Fix incomplete sentences but preserve speaker meaning
3. Normalize informal language to clear professional English
4. Keep all speaker labels intact (format: "SpeakerName: message")
5. Keep all timestamps
6. Standardize terminology — if the same thing is called by different names, note it
7. Do NOT remove any requirements, decisions, or business rules
8. Return the cleaned transcript as plain text"""

        user_prompt = f"Normalize this meeting transcript:\n\n{raw_transcript[:8000]}"

        llm_call("NORMALIZE", "Transcript normalization", len(user_prompt))
        result = await call_databricks_llm(system_prompt, user_prompt, max_tokens=6000)
        llm_response("NORMALIZE", len(result))
        return result

    async def _extract_from_transcript(self, transcript: str) -> List[Requirement]:
        system_prompt = """You are a Business Analyst extracting structured requirements from meeting transcripts.

Extract ALL of the following from the transcript:
- Functional requirements (what the system must DO)
- Non-functional requirements (performance, security, scalability, compliance, availability)
- Business rules (conditions, policies, constraints on behavior)
- Assumptions (things taken for granted, not explicitly confirmed)
- Constraints (hard limits: technology, budget, timeline, regulatory)
- Stakeholder information (names, roles, responsibilities mentioned)

For each item, output a JSON object with:
{
  "req_id": "TR-001",
  "type": "functional|non_functional|business_rule|assumption|constraint|stakeholder",
  "description": "clear, professional requirement statement",
  "source": "transcript",
  "speaker": "speaker name who stated this",
  "confidence": 0.0-1.0,
  "priority": "must_have|should_have|could_have|null",
  "module_tag": "authentication|payments|inventory|...",
  "acceptance_criteria": ["criterion 1", "criterion 2"] or null
}

Return a JSON array of ALL extracted items. Extract EVERYTHING."""

        user_prompt = f"Extract all requirements from this transcript:\n\n{transcript[:5000]}"

        llm_call("EXTRACT", "Requirement extraction from transcript", len(user_prompt))
        raw = await call_databricks_llm(system_prompt, user_prompt, max_tokens=8000, json_mode=True)
        llm_response("EXTRACT", len(raw))

        data = parse_llm_json(raw)
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and "requirements" in data:
            items = data["requirements"]
        else:
            warn("EXTRACT", f"Unexpected response structure: {type(data)}")
            items = []

        requirements = []
        skipped = 0
        for i, item in enumerate(items):
            try:
                if "req_id" not in item or not item["req_id"]:
                    item["req_id"] = f"TR-{str(i+1).zfill(3)}"
                requirements.append(Requirement(**item))
            except Exception as ex:
                warn("EXTRACT", f"Skipping item {i} ({item.get('req_id','?')}): {ex}")
                skipped += 1

        if skipped:
            warn("EXTRACT", f"{skipped} items skipped due to validation errors")
        return requirements

    async def _parse_user_stories(self, stories_text: str) -> List[Requirement]:
        system_prompt = """You are a Business Analyst parsing user stories into structured requirements.

For each user story found in the text, extract:
{
  "req_id": "US-001",
  "type": "functional",
  "description": "The system shall [action] so that [business value]",
  "source": "user_story",
  "speaker": null,
  "confidence": 1.0,
  "priority": "must_have|should_have|could_have",
  "module_tag": "authentication|payments|catalog|...",
  "user_story_id": "US-001",
  "acceptance_criteria": ["criterion 1", "criterion 2"]
}

Also extract any non-functional requirements hidden in acceptance criteria.
Return a JSON array."""

        user_prompt = f"Parse these user stories:\n\n{stories_text[:5000]}"

        llm_call("STORIES", "User story parsing", len(user_prompt))
        raw = await call_databricks_llm(system_prompt, user_prompt, max_tokens=8000, json_mode=True)
        llm_response("STORIES", len(raw))

        data = parse_llm_json(raw)
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and "requirements" in data:
            items = data["requirements"]
        else:
            warn("STORIES", f"Unexpected response structure: {type(data)}")
            items = []

        requirements = []
        skipped = 0
        for i, item in enumerate(items):
            try:
                if "req_id" not in item or not item["req_id"]:
                    item["req_id"] = f"US-{str(i+1).zfill(3)}"
                item["source"] = "user_story"
                requirements.append(Requirement(**item))
            except Exception as ex:
                warn("STORIES", f"Skipping story {i} ({item.get('req_id','?')}): {ex}")
                skipped += 1

        if skipped:
            warn("STORIES", f"{skipped} stories skipped due to validation errors")
        return requirements

    async def _build_glossary(self, all_text: str) -> Dict[str, str]:
        system_prompt = """You are a terminology specialist.
Identify all project-specific terms, acronyms, and concepts that appear with variation or need definition.

For each term write a clear definition.

Return JSON:
{
  "canonical_term": "definition and any aliases",
  ...
}

Focus on: system names, user roles, business processes, technical components, external systems."""

        user_prompt = f"Build a glossary from this project text:\n\n{all_text[:5000]}"

        llm_call("GLOSSARY", "Glossary extraction", len(user_prompt))
        raw = await call_databricks_llm(system_prompt, user_prompt, max_tokens=2000, json_mode=True)
        llm_response("GLOSSARY", len(raw))
        try:
            result = parse_llm_json(raw)
            return result if isinstance(result, dict) else {}
        except Exception as ex:
            warn("GLOSSARY", f"Glossary parse failed (non-fatal): {ex}")
            return {}
