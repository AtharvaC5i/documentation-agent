import React, { useState, useEffect, useRef } from "react";
import { Outlet, NavLink, useNavigate, useParams, useLocation } from "react-router-dom";
import { Home, HelpCircle, Plus, Terminal, ChevronDown, ChevronUp, Activity } from "lucide-react";

// ── Console log interceptor ──────────────────────────────────────────────────
// Captures all console.log/warn/error calls and stores them for the UI panel
const MAX_LOGS = 200;
const logListeners = [];
const logBuffer = [];

const originalLog = console.log;
const originalWarn = console.warn;
const originalError = console.error;

function interceptConsole() {
  const push = (level, args) => {
    const entry = {
      id: Date.now() + Math.random(),
      level,
      time: new Date().toLocaleTimeString("en-IN", { hour12: false }),
      text: args.map(a => (typeof a === "object" ? JSON.stringify(a, null, 2) : String(a))).join(" "),
    };
    logBuffer.push(entry);
    if (logBuffer.length > MAX_LOGS) logBuffer.shift();
    logListeners.forEach(fn => fn([...logBuffer]));
  };

  console.log = (...args) => { originalLog(...args); push("log", args); };
  console.warn = (...args) => { originalWarn(...args); push("warn", args); };
  console.error = (...args) => { originalError(...args); push("error", args); };
}
interceptConsole();

// Hook for components to write to the shared console
export function useConsoleLog() {
  return (msg) => console.log(`[BRD] ${msg}`);
}

// ── Stage nav config ─────────────────────────────────────────────────────────
const STAGES = [
  { key: "upload",      label: "1. Upload",     path: (id) => `/project/${id}/upload` },
  { key: "extraction",  label: "2. Extract",    path: (id) => `/project/${id}/extraction` },
  { key: "conflicts",   label: "3. Conflicts",  path: (id) => `/project/${id}/conflicts` },
  { key: "sections",    label: "4. Sections",   path: (id) => `/project/${id}/sections` },
  { key: "generation",  label: "5. Generate",   path: (id) => `/project/${id}/generation` },
  { key: "review",      label: "6. Review",     path: (id) => `/project/${id}/review` },
  { key: "complete",    label: "7. Done",       path: (id) => `/project/${id}/complete` },
];

function getStageFromPath(pathname) {
  for (const s of STAGES) {
    if (pathname.includes(`/${s.key}`)) return s.key;
  }
  return null;
}

function getProjectIdFromPath(pathname) {
  const m = pathname.match(/\/project\/([^/]+)\//);
  return m ? m[1] : null;
}

// ── Layout ───────────────────────────────────────────────────────────────────
export default function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [logs, setLogs] = useState([...logBuffer]);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const logEndRef = useRef(null);

  const currentStage = getStageFromPath(location.pathname);
  const currentProjectId = getProjectIdFromPath(location.pathname);
  const inProject = !!currentProjectId;

  // Subscribe to log updates
  useEffect(() => {
    const listener = (newLogs) => setLogs(newLogs);
    logListeners.push(listener);
    return () => {
      const i = logListeners.indexOf(listener);
      if (i !== -1) logListeners.splice(i, 1);
    };
  }, []);

  // Auto-scroll console
  useEffect(() => {
    if (autoScroll && consoleOpen && logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs, consoleOpen, autoScroll]);

  // Poll backend logs and forward to console
  useEffect(() => {
    if (!inProject) return;
    // Backend prints to its own terminal — we surface frontend-side events here
    // Backend logs appear in VS Code Terminal 1 directly
  }, [inProject]);

  const logColor = { log: "#a3e635", warn: "#fbbf24", error: "#f87171" };

  return (
    <div className="app-shell" style={{ flexDirection: "column" }}>
      <div style={{ display: "flex", flex: 1, minHeight: 0 }}>

        {/* ── Sidebar ── */}
        <aside className="sidebar">
          <div className="sidebar-logo">
            <h1>BRD Agent</h1>
            <span>AI Requirements Generator</span>
          </div>
          <nav className="sidebar-nav">
            <div className="nav-label">Main</div>
            <NavLink to="/" end className={({ isActive }) => `nav-item${isActive ? " active" : ""}`}>
              <Home size={16} /> Dashboard
            </NavLink>
            <NavLink to="/question-bank" className={({ isActive }) => `nav-item${isActive ? " active" : ""}`}>
              <HelpCircle size={16} /> Question Bank
            </NavLink>
            <div className="nav-label" style={{ marginTop: 12 }}>Project</div>
            <button className="nav-item" onClick={() => navigate("/new-project")}>
              <Plus size={16} /> New Project
            </button>

            {/* Stage navigator — only shows when inside a project */}
            {inProject && (
              <>
                <div className="nav-label" style={{ marginTop: 16 }}>Pipeline Stages</div>
                {STAGES.map((stage) => {
                  const isActive = currentStage === stage.key;
                  return (
                    <button
                      key={stage.key}
                      className={`nav-item${isActive ? " active" : ""}`}
                      style={{ fontSize: ".8rem", padding: "7px 12px" }}
                      onClick={() => navigate(stage.path(currentProjectId))}
                    >
                      <Activity size={13} />
                      {stage.label}
                    </button>
                  );
                })}
              </>
            )}
          </nav>

          {/* Console toggle button at bottom of sidebar */}
          <div style={{ padding: "12px", borderTop: "1px solid rgba(255,255,255,.1)" }}>
            <button
              className="nav-item"
              style={{ width: "100%", justifyContent: "space-between" }}
              onClick={() => setConsoleOpen(o => !o)}
            >
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <Terminal size={14} />
                Console
                {logs.length > 0 && (
                  <span style={{
                    background: "#06b6d4", color: "#fff",
                    borderRadius: "99px", padding: "1px 7px",
                    fontSize: ".65rem", fontWeight: 700
                  }}>{logs.length}</span>
                )}
              </span>
              {consoleOpen ? <ChevronDown size={13} /> : <ChevronUp size={13} />}
            </button>
          </div>
        </aside>

        {/* ── Main content ── */}
        <div className="main-content">
          <header className="topbar">
            <span className="topbar-title">BRD Generation Agent</span>
            <div className="flex items-center gap-3">
              {inProject && currentStage && (
                <span style={{
                  background: "#eff6ff", color: "#2563eb",
                  padding: "4px 12px", borderRadius: 99,
                  fontSize: ".78rem", fontWeight: 600
                }}>
                  Stage: {STAGES.find(s => s.key === currentStage)?.label}
                </span>
              )}
              <span className="text-sm text-muted">Powered by Databricks LLMs</span>
            </div>
          </header>
          <main className="page-body">
            <Outlet />
          </main>
        </div>
      </div>

      {/* ── Console panel — slides up from bottom ── */}
      {consoleOpen && (
        <div style={{
          position: "fixed", bottom: 0, left: "var(--sidebar-w)", right: 0,
          height: 280, background: "#0f172a",
          borderTop: "2px solid #1e3a5f",
          display: "flex", flexDirection: "column",
          zIndex: 200, fontFamily: "var(--mono)",
        }}>
          {/* Console header */}
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "6px 16px", background: "#1e293b",
            borderBottom: "1px solid #334155",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Terminal size={13} color="#94a3b8" />
              <span style={{ color: "#94a3b8", fontSize: ".75rem", fontWeight: 600, letterSpacing: ".05em" }}>
                CONSOLE — {logs.length} entries
              </span>
              <span style={{ color: "#475569", fontSize: ".7rem" }}>
                (Backend logs appear in VS Code Terminal 1)
              </span>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button
                onClick={() => setAutoScroll(a => !a)}
                style={{
                  background: autoScroll ? "#1d4ed8" : "#334155",
                  border: "none", borderRadius: 4, padding: "3px 10px",
                  color: "#fff", fontSize: ".7rem", cursor: "pointer"
                }}
              >
                {autoScroll ? "Auto-scroll ON" : "Auto-scroll OFF"}
              </button>
              <button
                onClick={() => { logBuffer.length = 0; setLogs([]); }}
                style={{
                  background: "#334155", border: "none", borderRadius: 4,
                  padding: "3px 10px", color: "#94a3b8", fontSize: ".7rem", cursor: "pointer"
                }}
              >
                Clear
              </button>
              <button
                onClick={() => setConsoleOpen(false)}
                style={{
                  background: "none", border: "none",
                  color: "#94a3b8", fontSize: "1rem", cursor: "pointer", padding: "0 4px"
                }}
              >
                ✕
              </button>
            </div>
          </div>

          {/* Log entries */}
          <div style={{ flex: 1, overflowY: "auto", padding: "8px 16px" }}>
            {logs.length === 0 && (
              <div style={{ color: "#475569", fontSize: ".78rem", marginTop: 8 }}>
                No frontend log entries yet. Backend logs appear in VS Code Terminal 1.
              </div>
            )}
            {logs.map((entry) => (
              <div key={entry.id} style={{
                display: "flex", gap: 12, marginBottom: 3,
                fontSize: ".75rem", lineHeight: 1.5,
              }}>
                <span style={{ color: "#475569", flexShrink: 0, minWidth: 70 }}>{entry.time}</span>
                <span style={{
                  color: logColor[entry.level] || "#a3e635",
                  whiteSpace: "pre-wrap", wordBreak: "break-all"
                }}>{entry.text}</span>
              </div>
            ))}
            <div ref={logEndRef} />
          </div>
        </div>
      )}
    </div>
  );
}
