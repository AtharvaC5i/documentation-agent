import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  CheckCircle, XCircle, RefreshCw, ChevronDown, ChevronRight,
  ThumbsUp, MessageSquare, Eye, FileDown, LayoutList
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { getSections, approveSection, regenerateSection, generateDocument, getProjectStatus } from "../utils/api";
import { usePolling } from "../hooks/usePolling";
import StepIndicator from "../components/StepIndicator";
import QualityBadge from "../components/QualityBadge";

export default function Review() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [sections, setSections] = useState([]);
  const [open, setOpen] = useState({});
  const [feedback, setFeedback] = useState({});
  const [feedbackOpen, setFeedbackOpen] = useState({});
  const [regenerating, setRegenerating] = useState({});
  const [generating, setGenerating] = useState(false);
  const [genStatus, setGenStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const r = await getSections(projectId);
    setSections(r.data.sections || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [projectId]);

  // Poll for regeneration status
  const [polling, setPolling] = useState(false);
  usePolling(async () => {
    if (Object.values(regenerating).some(Boolean)) {
      await load();
    }
    if (generating) {
      const s = await getProjectStatus(projectId);
      if (s.data.status === "complete") {
        navigate(`/project/${projectId}/complete`);
      }
    }
  }, 2500, polling || generating);

  const toggle = (id) => setOpen((o) => ({ ...o, [id]: !o[id] }));

  const handleApprove = async (sectionId, approved) => {
    await approveSection({ project_id: projectId, section_id: sectionId, approved });
    setSections((ss) => ss.map((s) => s.id === sectionId ? { ...s, approved, status: approved ? "approved" : "needs_revision" } : s));
  };

  const handleApproveAll = async () => {
    for (const s of sections) {
      await approveSection({ project_id: projectId, section_id: s.id, approved: true });
    }
    setSections((ss) => ss.map((s) => ({ ...s, approved: true, status: "approved" })));
  };

  const handleRegenerate = async (sectionId) => {
    const fb = feedback[sectionId] || "";
    setRegenerating((r) => ({ ...r, [sectionId]: true }));
    setPolling(true);
    await regenerateSection({ project_id: projectId, section_id: sectionId, feedback: fb });
    setFeedback((f) => ({ ...f, [sectionId]: "" }));
    setFeedbackOpen((f) => ({ ...f, [sectionId]: false }));
    setTimeout(async () => {
      await load();
      setRegenerating((r) => ({ ...r, [sectionId]: false }));
      setPolling(false);
    }, 3000);
  };

  const handleGenerateDoc = async () => {
    setGenerating(true);
    await generateDocument(projectId);
  };

  const approvedCount = sections.filter((s) => s.approved).length;
  const allApproved = approvedCount === sections.length && sections.length > 0;

  if (loading) return <div className="full-center"><div className="spinner" /></div>;

  return (
    <div>
      <StepIndicator current="review" />
      <div className="page-header">
        <h2>Human Review</h2>
        <p>Review each section, approve or request edits. Every paragraph traces back to its source.</p>
      </div>

      {/* Summary bar */}
      <div className="card mb-6" style={{ padding: "16px 24px" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div>
              <span className="font-bold" style={{ fontSize: "1.4rem", color: "#10b981" }}>{approvedCount}</span>
              <span className="text-muted text-sm"> / {sections.length} approved</span>
            </div>
            <div className="progress-bar-track" style={{ width: 160 }}>
              <div className="progress-bar-fill" style={{ width: `${sections.length > 0 ? (approvedCount / sections.length) * 100 : 0}%`, background: "#10b981" }} />
            </div>
          </div>
          <div className="flex gap-3">
            <button className="btn btn-secondary" onClick={() => navigate(`/project/${projectId}/pipeline`)}>
              <LayoutList size={15} /> Pipeline Inspector
            </button>
            {!allApproved && (
              <button className="btn btn-success" onClick={handleApproveAll}>
                <ThumbsUp size={15} /> Approve All
              </button>
            )}
            <button
              className="btn btn-primary"
              disabled={generating}
              onClick={handleGenerateDoc}
            >
              {generating
                ? <><div className="spinner" style={{ width: 15, height: 15 }} /> Generating document...</>
                : <><FileDown size={15} /> Generate BRD Document</>}
            </button>
          </div>
        </div>
      </div>

      {/* Section cards */}
      {sections.map((section, idx) => (
        <div key={section.id} className="section-review-card" style={{ marginBottom: 12, border: section.approved ? "1.5px solid #a7f3d0" : section.status === "needs_revision" ? "1.5px solid #fecaca" : "1.5px solid var(--grey-200)" }}>
          {/* Header */}
          <div className="section-review-header" onClick={() => toggle(section.id)}>
            <div className="flex items-center gap-3">
              <span className="text-muted text-sm" style={{ minWidth: 24 }}>{idx + 1}</span>
              {section.approved
                ? <CheckCircle size={17} color="#10b981" />
                : section.status === "needs_revision"
                ? <XCircle size={17} color="#ef4444" />
                : <div style={{ width: 17, height: 17, borderRadius: "50%", border: "2px solid var(--grey-300)" }} />}
              <span className="font-semibold">{section.name}</span>
              <QualityBadge score={section.quality_score || 0} />
              {section.status === "regenerated" && <span className="badge badge-blue">Regenerated</span>}
              {section.req_count > 0 && <span className="text-xs text-muted">{section.req_count} requirements</span>}
            </div>
            <div className="flex items-center gap-2">
              {section.sources?.map((src) => (
                <span key={src} className="badge badge-grey" style={{ fontSize: ".68rem" }}>{src}</span>
              ))}
              {open[section.id] ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </div>
          </div>

          {/* Body */}
          {open[section.id] && (
            <div style={{ padding: "20px 24px" }}>
              {/* Content preview */}
              <div style={{ background: "var(--grey-50)", borderRadius: 8, padding: "16px 20px", marginBottom: 16, maxHeight: 500, overflowY: "auto" }}>
                <div className="md-content">
                  <ReactMarkdown>{section.content || "*No content generated.*"}</ReactMarkdown>
                </div>
              </div>

              {/* Source refs */}
              {section.source_req_ids?.length > 0 && (
                <div className="mb-4">
                  <div className="text-xs font-semibold text-muted mb-2">SOURCE REQUIREMENTS</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                    {section.source_req_ids.map((id) => (
                      <code key={id} style={{ background: "var(--grey-100)", padding: "2px 7px", borderRadius: 4, fontSize: ".75rem", color: "var(--grey-700)" }}>{id}</code>
                    ))}
                  </div>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex gap-3" style={{ flexWrap: "wrap" }}>
                {!section.approved && (
                  <button className="btn btn-success btn-sm" onClick={() => handleApprove(section.id, true)}>
                    <CheckCircle size={14} /> Approve
                  </button>
                )}
                {section.approved && (
                  <button className="btn btn-secondary btn-sm" onClick={() => handleApprove(section.id, false)}>
                    <XCircle size={14} /> Unapprove
                  </button>
                )}
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setFeedbackOpen((f) => ({ ...f, [section.id]: !f[section.id] }))}
                >
                  <MessageSquare size={14} /> {feedbackOpen[section.id] ? "Hide" : "Request Edits"}
                </button>
              </div>

              {/* Feedback form */}
              {feedbackOpen[section.id] && (
                <div style={{ marginTop: 14, background: "var(--blue-pale)", borderRadius: 8, padding: 14 }}>
                  <div className="text-sm font-semibold mb-2">What needs to change?</div>
                  <textarea
                    className="form-textarea"
                    style={{ minHeight: 70, marginBottom: 10 }}
                    placeholder='e.g. "Add microservices communication details to Architecture section" or "The EMI section missed the Bajaj Finance specifics"'
                    value={feedback[section.id] || ""}
                    onChange={(e) => setFeedback((f) => ({ ...f, [section.id]: e.target.value }))}
                  />
                  <button
                    className="btn btn-primary btn-sm"
                    disabled={regenerating[section.id] || !feedback[section.id]?.trim()}
                    onClick={() => handleRegenerate(section.id)}
                  >
                    {regenerating[section.id]
                      ? <><div className="spinner" style={{ width: 13, height: 13 }} /> Regenerating...</>
                      : <><RefreshCw size={13} /> Regenerate with Feedback</>}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ))}

      {/* Bottom generate button */}
      <div className="card mt-6" style={{ padding: "20px 24px", background: "var(--navy)", border: "none" }}>
        <div className="flex items-center justify-between">
          <div>
            <div className="font-semibold" style={{ color: "#fff" }}>Ready to generate the final BRD?</div>
            <div className="text-sm" style={{ color: "rgba(255,255,255,.6)", marginTop: 3 }}>
              {allApproved
                ? "All sections approved — document will include all sections."
                : `${approvedCount} of ${sections.length} sections approved. Unapproved sections will still be included.`}
            </div>
          </div>
          <button
            className="btn btn-lg"
            style={{ background: "#06b6d4", color: "#fff" }}
            disabled={generating}
            onClick={handleGenerateDoc}
          >
            {generating
              ? <><div className="spinner" style={{ width: 16, height: 16, borderTopColor: "#fff" }} /> Generating...</>
              : <><FileDown size={16} /> Generate & Download BRD</>}
          </button>
        </div>
      </div>
    </div>
  );
}
