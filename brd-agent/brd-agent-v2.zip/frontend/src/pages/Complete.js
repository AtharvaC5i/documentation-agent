import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { CheckCircle, Download, FileText, BarChart2, Plus, RefreshCw, Loader } from "lucide-react";
import { getSections, listProjects } from "../utils/api";
import { downloadBRD } from "../utils/download";
import StepIndicator from "../components/StepIndicator";
import QualityBadge from "../components/QualityBadge";

export default function Complete() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [sections, setSections] = useState([]);
  const [project, setProject] = useState(null);
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState("");

  useEffect(() => {
    getSections(projectId)
      .then((r) => setSections(r.data.sections || []))
      .catch(() => {});
    listProjects()
      .then((r) => {
        const p = (r.data.projects || []).find((p) => p.id === projectId);
        if (p) setProject(p);
      })
      .catch(() => {});
  }, [projectId]);

  const handleDownload = async () => {
    setDownloading(true);
    setDownloadError("");
    try {
      await downloadBRD(projectId, project?.project_name || "BRD");
    } catch (e) {
      setDownloadError(e.message);
    } finally {
      setDownloading(false);
    }
  };

  const avgQuality = sections.length > 0
    ? sections.reduce((a, s) => a + (s.quality_score || 0), 0) / sections.length
    : 0;

  const approvedCount = sections.filter((s) => s.approved).length;
  const regeneratedCount = sections.filter((s) => s.status === "regenerated").length;
  const totalReqs = sections.reduce((a, s) => a + (s.req_count || 0), 0);

  return (
    <div style={{ maxWidth: 700 }}>
      <StepIndicator current="complete" />

      {/* Hero */}
      <div className="card mb-6" style={{ background: "linear-gradient(135deg, #0f1f3d 0%, #1a3259 100%)", border: "none", padding: "40px 36px", textAlign: "center" }}>
        <div style={{ width: 64, height: 64, borderRadius: "50%", background: "#10b981", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
          <CheckCircle size={32} color="#fff" />
        </div>
        <h2 style={{ color: "#fff", fontSize: "1.6rem", fontWeight: 700, marginBottom: 6 }}>BRD Generated Successfully</h2>
        <p style={{ color: "rgba(255,255,255,.65)", marginBottom: 24 }}>Your Business Requirements Document is ready for download.</p>

        <button
          className="btn btn-lg"
          style={{ background: "#06b6d4", color: "#fff", display: "inline-flex", opacity: downloading ? 0.7 : 1 }}
          onClick={handleDownload}
          disabled={downloading}
        >
          {downloading
            ? <><Loader size={18} className="spin" /> Preparing download...</>
            : <><Download size={18} /> Download BRD (.docx)</>}
        </button>

        {downloadError && (
          <div style={{ marginTop: 14, background: "rgba(239,68,68,.15)", border: "1px solid rgba(239,68,68,.4)", borderRadius: 8, padding: "10px 14px", color: "#fca5a5", fontSize: ".85rem" }}>
            {downloadError}
          </div>
        )}
      </div>

      {/* Generation report */}
      <div className="card mb-6">
        <div className="flex items-center gap-2 mb-4">
          <BarChart2 size={18} color="#2563eb" />
          <div className="card-title" style={{ marginBottom: 0 }}>Generation Report</div>
        </div>
        <div className="grid-2">
          {[
            { label: "Sections Generated", value: sections.length, color: "#2563eb" },
            { label: "Avg Quality Score", value: `${Math.round(avgQuality * 100)}%`, color: avgQuality >= 0.8 ? "#10b981" : avgQuality >= 0.6 ? "#f59e0b" : "#ef4444" },
            { label: "Sections Approved", value: approvedCount, color: "#10b981" },
            { label: "Auto-Regenerated", value: regeneratedCount, color: "#f59e0b" },
            { label: "Requirements Used", value: totalReqs, color: "#06b6d4" },
            { label: "Project", value: project?.project_name || "—", color: "#64748b" },
          ].map((stat) => (
            <div key={stat.label} className="flex items-center justify-between" style={{ padding: "10px 0", borderBottom: "1px solid var(--grey-100)" }}>
              <span className="text-sm text-muted">{stat.label}</span>
              <span className="font-bold" style={{ color: stat.color }}>{stat.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Per-section quality */}
      <div className="card mb-6">
        <div className="card-title mb-4">Section Quality Breakdown</div>
        <table className="data-table">
          <thead><tr><th>Section</th><th>Quality</th><th>Status</th></tr></thead>
          <tbody>
            {sections.map((s) => (
              <tr key={s.id}>
                <td className="text-sm font-semibold">{s.name}</td>
                <td><QualityBadge score={s.quality_score || 0} /></td>
                <td>
                  {s.approved
                    ? <span className="badge badge-green">Approved</span>
                    : <span className="badge badge-orange">Pending</span>}
                  {s.status === "regenerated" && <span className="badge badge-blue" style={{ marginLeft: 4 }}>Regenerated</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Actions */}
      <div className="card">
        <div className="card-title mb-4">What's Next?</div>
        <div className="flex gap-3" style={{ flexWrap: "wrap" }}>
          <button className="btn btn-primary" onClick={handleDownload} disabled={downloading}>
            <Download size={15} /> Download Again
          </button>
          <button className="btn btn-secondary" onClick={() => navigate(`/project/${projectId}/review`)}>
            <RefreshCw size={15} /> Back to Review
          </button>
          <button className="btn btn-secondary" onClick={() => navigate("/new-project")}>
            <Plus size={15} /> New Project
          </button>
          <button className="btn btn-secondary" onClick={() => navigate("/")}>
            <FileText size={15} /> Dashboard
          </button>
        </div>
        <div className="alert alert-info mt-4">
          <FileText size={15} style={{ flexShrink: 0 }} />
          <div className="text-sm">
            <strong>Living Document:</strong> When you have a follow-up client call, upload the new transcript to update this BRD. The agent will detect what changed and flag sections that need revision.
          </div>
        </div>
      </div>

      <style>{`.spin { animation: spin .8s linear infinite; } @keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
